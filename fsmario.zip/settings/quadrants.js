FullScreenMario.prototype.settings.quadrants = {
    "numRows": 5,
    "numCols": 6,
    "tolerance": FullScreenMario.unitsize / 2,
    "groupNames": ["Solid", "Character", "Scenery", "Text"],
    "thingGroupName": "groupType"
}
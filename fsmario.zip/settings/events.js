FullScreenMario.prototype.settings.events = {
    "keyOnSpriteCycleStart": "onThingAdd",
    "keyDoSpriteCycleStart": "placed",
    "keyCycleCheckValidity": "alive",
    "timingDefault": 9
};